#simulazione di fisica

