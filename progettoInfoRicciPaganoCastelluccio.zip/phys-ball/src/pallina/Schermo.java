package pallina;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Schermo extends JLabel{

	private Palla palla;

	private boolean enabled = false;
	private double gravita;
	private boolean play = false;
	
	public Schermo() {
		super();
		palla = new Palla(100, 100,Color.red, 30);
		this.setBackground(Color.white);
		
		palla.setVelX(0);
		palla.setVelY(0);
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D	g2 = (Graphics2D)g;
		
		paintPalla(g2);

		if (play) { //se il pulsante play � stato premuto allora eseguo le istruzioni per muovere la pallina
			this.aggiornaPosizione(0.01); //
			this.risolviCollisioni();
			
			if(enabled)
				this.simulaAttrito();
		}
	}
	
	private void simulaAttrito() {
		
		if(palla.getVelY() < 0.01 && palla.getPosY()-palla.getRaggio()<0.02) {
			palla.setVelY(0);
			palla.setPosY(palla.getRaggio());}
		else
			palla.setVelY( palla.getVelY() >0 ? palla.getVelY()-1 : palla.getVelY()+1);
		
		palla.setVelX(palla.getVelX() >0 ? palla.getVelX()-0.09 : palla.getVelX()+0.09);
		
	}

	public boolean isPlay() {
		return play;
	} 

	public void setPlay(boolean play) {
		this.play = play;
	}

	private void risolviCollisioni() {
		double vx,vy;
		if(palla.getPosX()+palla.getRaggio() >= this.getWidth() || palla.getPosX()-palla.getRaggio() <= 0) 
		{	vx = palla.getVelX() ;

			palla.setVelX(vx*-1);
		}
		if(palla.getPosY()+palla.getRaggio() >= this.getHeight() || palla.getPosY()-palla.getRaggio() <= 0) 
		{	vy = palla.getVelY() ;
			
			palla.setVelY(vy*-1);
		}

	}
	
	//disegno la palla
	private void paintPalla(Graphics2D g2) {
		int raggio = palla.getRaggio();
		int x = Palla.convertFloat( palla.getPosX() );
		int y = Palla.convertFloat(this.getHeight()-palla.getPosY());
		g2.setColor(palla.getColor());
		g2.fillOval(x-raggio, y-raggio, 2*raggio, 2*raggio);
		
	}
	
	
	//aggiorno la posizione della palla in seguito alla velocit�
	public void aggiornaPosizione(double time){
		
		palla.setPosX((float) (palla.getPosX() + palla.getVelX()*time));
		palla.setPosY((float) (palla.getPosY() + palla.getVelY()*time));
		
		if(enabled)  //se la gravit� � abilitata 
			palla.setVelY(palla.getVelY() - gravita);
		
	}
	
	public void setGravity(double gravita) {
		this.gravita = gravita;
	}

	public Palla getPalla() {
		return palla;
	}

	public void setPalla(Palla p) {
		this.palla = p;
	}

	public void setGravity(boolean selected) {
		this.enabled = selected;	
	}

	public void reset() {					//mette la palla al centro con velocit� x (orizzontale) casuale
		Random r = new Random();
		palla.setPosX(this.getWidth()/2);
		palla.setPosY(this.getHeight()/2);
		palla.setVelY(0);
		palla.setVelX(r.nextFloat()*300);
		
	}
	
	public void setSfondo(ImageIcon i) {  
		this.setIcon(i);
	}
		
}