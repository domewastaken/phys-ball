package pallina;

import java.awt.Color;
import java.awt.EventQueue;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;

import javax.swing.JLabel;

import javax.swing.SwingConstants;

import javax.swing.JCheckBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

import javax.swing.ImageIcon;


public class appPallina {

	private JFrame frmGravit;

	private String[] hexColori = { "#FF0000","#FFFF00","#0000FF","#654321","#000000","#800080","#00FF00","#FF00FF"};		//esadecimali dei colori dell'arrColori
	private String[] arrColori = {"Rosso", "Giallo", "Blu", "Marrone", "Nero", "Viola", "Verde", "Rosa"};
	private String[] arrPianeti = {"Terra", "Luna", "Marte", "Giove"};
	private double[] arrGravita = {9.81, 1.62, 3.72, 24.79};
	private int gigio;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					appPallina window = new appPallina();
					window.frmGravit.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public appPallina() {
		initialize();
	}

	private void initialize() {
		
		frmGravit = new JFrame();
		frmGravit.setIconImage(getImmagine("apple.png").getImage());
		frmGravit.setResizable(false);
		frmGravit.setTitle("Gravity Simulator 2021");
		frmGravit.setBounds(100, 100, 749, 507);
		frmGravit.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frmGravit.getContentPane().setLayout(null);
		Schermo schermo = new Schermo();
		schermo.setBounds(10, 11, 511, 446);
		frmGravit.getContentPane().add(schermo);
		schermo.setSfondo( getImmagine("bianco.png") );
		JCheckBox chbGravity = new JCheckBox("gravit\u00E0");
		chbGravity.setBounds(536, 193, 97, 23);
		frmGravit.getContentPane().add(chbGravity);
		
		JComboBox cmbColore = new JComboBox(arrColori);
		
		cmbColore.setBounds(539, 140, 140, 32);
		frmGravit.getContentPane().add(cmbColore);
		
		JLabel lblSelezionaIlColore = new JLabel("Seleziona il colore:");
		lblSelezionaIlColore.setHorizontalAlignment(SwingConstants.LEFT);
		lblSelezionaIlColore.setBounds(539, 114, 140, 14);
		frmGravit.getContentPane().add(lblSelezionaIlColore);
		
		JLabel lblVelxPallina = new JLabel("Vel-X pallina : ");
		lblVelxPallina.setBounds(539, 40, 94, 20);
		frmGravit.getContentPane().add(lblVelxPallina);
		
		JLabel lblVelyPallina = new JLabel("Vel-Y pallina : ");
		lblVelyPallina.setBounds(539, 66, 94, 20);
		frmGravit.getContentPane().add(lblVelyPallina);
		
		JLabel ScVelX = new JLabel("");
		ScVelX.setBounds(633, 46, 89, 14);
		frmGravit.getContentPane().add(ScVelX);
		
		JLabel ScVelY = new JLabel("");
		ScVelY.setBounds(633, 66, 89, 14);
		frmGravit.getContentPane().add(ScVelY);
		
		JButton btnReset = new JButton("reset");
		btnReset.setBounds(633, 416, 89, 23);
		frmGravit.getContentPane().add(btnReset);
		
		JLabel PlayPausa = new JLabel("");
				
		schermo.setGravity(9.81); 			//gravit� iniziale ovvero la Terra
		
		PlayPausa.addMouseListener(new MouseAdapter() {
			@Override									
			public void mouseClicked(MouseEvent arg0) {
				if(gigio == 0) {			

					gigio = 1;			
					schermo.setPlay(true);				//mette play 
					
					PlayPausa.setIcon(getImmagine("pauseButton.png"));  	//mette l'immagine per la pausa
				}else {
					gigio = 0;
					schermo.setPlay(false);				//mette in pausa
					PlayPausa.setIcon(getImmagine("playButton.png"));		//mette l'immagine per il play
				}
				
			}
		});
		
		PlayPausa.setHorizontalAlignment(SwingConstants.CENTER);
		PlayPausa.setIcon( getImmagine("playButton.png") );
		PlayPausa.setBounds(543, 393, 72, 64);
		
		frmGravit.getContentPane().add(PlayPausa);
		
		JComboBox cmbPianeti = new JComboBox(arrPianeti);
		
		cmbPianeti.setBounds(539, 261, 143, 25);
		frmGravit.getContentPane().add(cmbPianeti);
		
		JLabel lblPianeti = new JLabel("Seleziona il pianeta:");
		lblPianeti.setBounds(539, 233, 140, 16);
		frmGravit.getContentPane().add(lblPianeti);
		
		JCheckBox chckbxAbilitaSfondo = new JCheckBox("abilita sfondo");
		chckbxAbilitaSfondo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!chckbxAbilitaSfondo.isSelected())
					schermo.setSfondo( getImmagine("bianco.png"));
				else
					schermo.setSfondo( getImmagine(arrPianeti[cmbPianeti.getSelectedIndex()]+".png"));
				
					
			}
		});
		chckbxAbilitaSfondo.setBounds(536, 310, 130, 23);
		frmGravit.getContentPane().add(chckbxAbilitaSfondo);
		
		cmbPianeti.setEnabled(false);
		chckbxAbilitaSfondo.setEnabled(false);
		
		btnReset.addActionListener(e->{
			schermo.reset();
		});
		
		cmbColore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				schermo.getPalla().setColor( Color.decode(hexColori[cmbColore.getSelectedIndex()]) );
				
			}
		});
		
		cmbPianeti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				schermo.setGravity( arrGravita[cmbPianeti.getSelectedIndex()] );
				
				if(chckbxAbilitaSfondo.isSelected())
					schermo.setSfondo( getImmagine(arrPianeti[cmbPianeti.getSelectedIndex()]+".png") );
				
			}
		});
		
		chbGravity.addActionListener(e->{
					
			schermo.setGravity( chbGravity.isSelected());
			
			if(!chbGravity.isSelected()) {					
				cmbPianeti.setEnabled(false);					//disabilita scelta pianeti 
				chckbxAbilitaSfondo.setEnabled(false);			//disabilita scelta sfondo
				chckbxAbilitaSfondo.setSelected(false);			//toglie la spunta alla combobox sfondo
				schermo.setSfondo( getImmagine("bianco.png"));	//mette lo sfondo bianco
			}else {
				cmbPianeti.setEnabled(true);             //abilita scelta pianeti
				chckbxAbilitaSfondo.setEnabled(true);	 //abilita scelta sfondo
			}
		});
		
		Timer t = new Timer();
		
		t.schedule(new TimerTask() {
			
			@Override
			public void run() {
				
				ScVelX.setText(schermo.getPalla().getVelX()+"");
				ScVelY.setText(schermo.getPalla().getVelY()+"");
				schermo.repaint();
				
			}
		}, 1, 10);		//richiamato ogni 10 millisecondi
	
	}
	
	private ImageIcon getImmagine(String p) {					//metodo che aiuta a gestire le immagini
		return new ImageIcon(getClass().getResource(p));
	}
}
